# semtk-python3
This package contains python3 clients to the SemTK services.

## Build whl file
```
pip install dateutil
pip install requests
pip install wheel
python3 setup.py sdist bdist_wheel
```

## Install whl file
```
python -m pip install /path/to/whl/file
```
