'''
Created on May 6, 2019

@author: 200001934
'''

import sys

def foo():
    sys.stdout.write("success\n")